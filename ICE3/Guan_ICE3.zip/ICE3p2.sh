#!/bin/bash
# Alex Guan

read -p "Please enter your first and last name: " first_name last_name
echo "Your first name is $first_name"
echo "Your last name is $last_name"
