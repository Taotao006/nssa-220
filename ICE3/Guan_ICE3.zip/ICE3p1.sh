#!/bin/bash
# Alex Guan

ran1=$RANDOM
ran2=$RANDOM
ran3=$RANDOM
ran4=$RANDOM
ran5=$RANDOM
echo $ran1 $ran2 $ran3 $ran4 $ran5
echo "$SECONDS seconds have passed"
